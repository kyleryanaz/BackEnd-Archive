const Sequelize = require("Sequelize");
const sqlite3 = require("sqlite3").verbose();
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const handlebars = require("express-handlebars").create({
  defaultLayout: "main"
});
app.engine("handlebars", handlebars.engine);

app.set("view engine", "handlebars");

app.set("port", process.env.PORT || 3000);

app.use(bodyParser.json());

// app.use(bodyParser.urlencoded({ extended: true }));

const sequelize = new Sequelize("SequelizeMusic", "Kyle", null, {
  host: "localhost",
  dialect: "sqlite",
  storage: "./Chinook_Sqlite_AutoIncrementPKs.sqlite"
});

const Artist = sequelize.define(
  "Artist",
  {
    ArtistId: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    Name: Sequelize.STRING
  },
  {
    freezeTableName: true,
    timestamps: false
  }
);

const Album = sequelize.define(
  "Album",
  {
    AlbumId: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    Title: Sequelize.STRING
  },
  {
    freezeTableName: true,
    timestamps: false
  }
);
Artist.hasMany(Album, { foreignKey: "ArtistId" });
Album.belongsTo(Artist, { foreignKey: "ArtistId" });

app.get("/", (request, response) => {
  Album.findAll({
    include: [
      {
        model: Artist
      }
    ]
  }).then(albums => {
    console.log("this works", albums);
    response.render("albums", { albums: albums });
  });
});

app.listen(app.get("port"), () => {
  console.log(
    "Listening on http://localhost:" +
      app.get("port") +
      "; press Ctrl-c to terminate."
  );
});
