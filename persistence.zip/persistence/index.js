const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const app = express();
const db = new sqlite3.Database("./musicDB");
const bodyParser = require("body-parser");
const handlebars = require("express-handlebars").create({
  defaultLayout: "main"
});
app.engine("handlebars", handlebars.engine);

app.set("view engine", "handlebars");

app.set("port", process.env.PORT || 3000);

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));

// const stmt = db.prepare(`INSERT INTO Artists (ArtistId, Name) VALUES (?, ?)`);

// stmt.run(278, "Kenny Loggins");

app.get("/", (request, response) => {
  response.render("form");
});

app.get("/success", (request, response) => {
  response.render("success");
});

app.get("/albums", (request, response) => {
  const query = `SELECT artists.Name as Artist, albums.Title as Album from artists JOIN albums USING (artistId)`;
  let resultsArray = [];
  db.each(query, (err, row) => {
    if (err) throw err;
    // console.log(row);
    resultsArray.push(row);
  });
  response.render("albums", { results: resultsArray });
});

app.post("/form", (request, response) => {
  db.run(
    `INSERT into Artists(ArtistId, Name) VALUES(${request.body.artistId}, '${
      request.body.name
    }')`,
    (err, row) => {
      if (err) throw err;
      db.close();
      response.redirect(303, "/success");
    }
  );
});

app.listen(app.get("port"), () => {
  console.log(
    "Listening on http://localhost:" +
      app.get("port") +
      "; press Ctrl-c to terminate."
  );
});
