const express = require("express");
const app = express();
app.use(require("body-parser")());

app.listen(3000, () => {
  console.log("Simple Server is running on 3000");
});

//Create routes
//API endpoints

app.get("/", function(req, res) {
  console.log("GET was called.");
  res.status(201).send("GET is used to read information");
  console.log(req.headers);
});

app.post("/", function(req, res) {
  console.log("POST was called.");
  res.status(201).send("Data can be created using this method (POST)");
  console.log(req.headers);
});

app.put("/", function(req, res) {
  console.log("PUT was called.");
  res.status(201).send("Use this (PUT) to update information");
  console.log(req.headers);
});

app.delete("/", function(req, res) {
  console.log("DELETE was called.");
  // res.send("Only use DELETE to remove the specified target");
  res.status(403).send("YOU ARE FORBIDDEN!");
  console.log(req.headers);
});
